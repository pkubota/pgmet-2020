gfortran -o CLIRADTFd CliradTFd.f kuv_b.f kir_b.f
