Clirad prepared for Global instead of lwrad.f90

with aerosol

gfortran -o CLIRADLWaer mainlwaer.f90 CliradLWaer.f90


Inputs:

MLSn.d
TRAn.d

mainlw_aer.in


Outputs:

mainlw_aer.out

