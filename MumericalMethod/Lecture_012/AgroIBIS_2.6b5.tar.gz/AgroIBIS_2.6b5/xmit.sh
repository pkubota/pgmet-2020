#!/bin/sh
#
ulimit -s unlimited 
cd /scratchin/grupos/bam/home/paulo.kubota/AgroIBIS_2.6b5
/scratchin/grupos/bam/home/paulo.kubota/AgroIBIS_2.6b5/ibis-2.6b5.exe < /scratchin/grupos/bam/home/paulo.kubota/AgroIBIS_2.6b5/IBISIN
